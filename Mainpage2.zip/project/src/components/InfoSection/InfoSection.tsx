import React from 'react';
import { ArrowRight } from 'lucide-react';

interface InfoSectionProps {
  title: string;
  subtitle: string;
  description: string[];
  buttonText: string;
  buttonUrl: string;
  reverse?: boolean;
}

const InfoSection: React.FC<InfoSectionProps> = ({
  title,
  subtitle,
  description,
  buttonText,
  buttonUrl,
  reverse = false,
}) => {
  return (
    <section className="py-16 md:py-24 bg-[#fbefef]">
      <div className="container mx-auto px-4">
        <div className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center gap-8 md:gap-16`}>
          <div className="w-full md:w-1/2 text-center md:text-left">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-800 mb-4">{title}</h2>
            <h3 className="text-xl md:text-2xl text-gray-700 mb-6">{subtitle}</h3>
            
            <div className="space-y-4 mb-8">
              {description.map((paragraph, index) => (
                <p key={index} className="text-gray-600 leading-relaxed">{paragraph}</p>
              ))}
            </div>
            
            <a
              href={buttonUrl}
              className="inline-flex items-center px-6 py-3 bg-[#f5a9a9] text-white rounded-lg hover:bg-opacity-90 transition-all transform hover:translate-y-[-2px]"
            >
              {buttonText}
              <ArrowRight className="ml-2 w-4 h-4" />
            </a>
          </div>
          
          <div className="w-full md:w-1/2 flex justify-center md:justify-end">
            <div className="w-full max-w-md h-96 bg-gray-200 rounded-xl overflow-hidden shadow-lg relative">
              {/* This div would typically contain an image or illustration */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#f5a9a9] to-pink-300 opacity-30"></div>
              {/* Content placeholder - in a real implementation, replace with actual content */}
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-gray-500 text-lg">Visual content here</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InfoSection;
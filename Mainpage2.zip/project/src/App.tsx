import React from 'react';
import Header from './components/Header/Header';
import Hero from './components/Hero/Hero';
import InfoSection from './components/InfoSection/InfoSection';
import AppDemo from './components/AppDemo/AppDemo';
import FeatureSection from './components/FeatureSection/FeatureSection';
import MobilePreview from './components/MobilePreview/MobilePreview';
import CountrySection from './components/CountrySection/CountrySection';
import Footer from './components/Footer/Footer';
import { navLinks, heroSlides, features } from './data/mockData';

import traditional_lottetower from './assets/traditional_lottetower.jpg'; // 이미지 불러오기


function App() {
  return (
    <div className="min-h-screen bg-[#fbefef]">
      <Header links={navLinks} />
      <Hero slides={heroSlides} />
      
      <CountrySection 
        title="외국인에 의한, 외국인을 위한 ForForeigner"
        subtitle="한국의 모든 것, 생활부터 언어까지 한번에"
        imageSrc={traditional_lottetower} //  전통+롯데타워 이미지 사용 //ForForeigner 한줄 소개
      />
      
      <InfoSection  //문화 퀴즈 예시
        title="한국인에게 얼죽아란?"
        subtitle="퀴즈 게임으로 문화를 공부해요!"
        description={[
          "한겨울에도 아아를 마시는 한국인,",
          "이런 한국의 커피 문화가 궁금하다면?"
        ]}
        buttonText="문화 알아가기"
        buttonUrl="#examples"
      />
      
      <MobilePreview //줄임말 퀴즈 예시
        title="한국인 친구들의 줄임말이 어려울 때"
        description={[
          
          "지금 퀴즈를 통해 줄임말에 대해 배워가요!"
        ]}
      />

      
      <AppDemo />
      
      <InfoSection  //커뮤니티 소개
        title="당신의 한국 생활,"
        subtitle="ForForeigner 커뮤니티와 함께해요."
        description={[
          "한국어가 유창하지 않아도, 한국에 대해 많이 알지 않아도 괜찮아요.",
          "다양한 사람들과 소통하면서 정보를 얻어요!",
        ]}
        buttonText="커뮤니티 방문하기"
        buttonUrl="#start"
        reverse={true}
      />
      
      
      
      
      <FeatureSection //6가지 기능 소개 문구
        title="ForForeigner와 함께"
        subtitle="한국어 학습과 문화 적응을 위한 완벽한 동반자"
        features={features}
      />

      <Footer />
    </div>
  );
}

export default App;

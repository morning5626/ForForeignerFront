import React, { useState, useEffect } from 'react';
import { Globe } from 'lucide-react';
import { Link as RouterLink } from 'react-router-dom';
import { Link } from '../../types';

interface HeaderProps {
  links: Link[];
}

const Header: React.FC<HeaderProps> = ({ links }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed w-full z-50 bg-white shadow-md py-2">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <a href="#" className="text-2xl font-bold flex items-center">
            <span className="text-gray-800">For</span>
            <span className="text-[#f5a9a9]">F</span>
            <Globe className="w-5 h-5 text-blue-600 mx-1" />
            <span className="text-gray-800">reigner</span>
          </a>
        </div>

        {/* 상단 네비게이션 */}
        <nav className="hidden md:flex items-center space-x-8">
          {links.map((link) => (
            <RouterLink
              key={link.id}
              to={link.url}
              className="text-gray-700 hover:text-[#f5a9a9] transition-colors"
            >
              {link.title}
            </RouterLink>
            
          ))}
          <button className="bg-white border border-gray-300 px-3 py-1 rounded-md flex items-center">
            <Globe className="w-4 h-4 mr-1" />
            <span>ENG</span>
          </button>
        </nav>

        {/* 메뉴 버튼 */}
        <button
          className="md:hidden text-gray-700"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}
            />
          </svg>
        </button>
      </div>

      {/* 메뉴 */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg py-4 px-4 absolute w-full">
          <nav className="flex flex-col space-y-4">
            {links.map((link) => (
              <RouterLink
                key={link.id}
                to={link.url}
                className="text-gray-700 hover:text-[#f5a9a9] transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                {link.title}
              </RouterLink>
            ))}
            <button className="bg-white border border-gray-300 px-3 py-1 rounded-md self-start flex items-center">
              <Globe className="w-4 h-4 mr-1" />
              <span>ENG</span>
            </button>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
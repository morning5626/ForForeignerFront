import React from 'react';
import {
  ArrowRight,
  MessageCircle,
  Sprout,
  BookOpen,
  User,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface InfoSectionProps {
  title: string;
  subtitle: string;
  description: string[];
  buttonText: string;
  buttonUrl: string;
  reverse?: boolean;
  showFeatureBoxes?: boolean;
}

const InfoSection: React.FC<InfoSectionProps> = ({
  title,
  subtitle,
  description,
  buttonText,
  buttonUrl,
  reverse = false,
  showFeatureBoxes = false,
}) => {
  const navigate = useNavigate(); // useNavigate는 컴포넌트 내부에서 호출하기

  const features = [
    {
      title: '자유게시판',
      desc: ['당신의 생각을', '자유롭게 나눠보세요!'],
      icon: <MessageCircle className="w-5 h-5 text-[#f5a9a9]" />,
      link: '/board/free',
    },
    {
      title: '뉴비게시판',
      desc: ['한국이 처음이라 어려운 당신,', '여기서 레벨업해요!'],
      icon: <Sprout className="w-5 h-5 text-[#f5a9a9]" />,
      link: '/board/newbie',
    },
    {
      title: '정보게시판',
      desc: ['한국 생활의 팁과 정보를', '여기 다 모였다!'],
      icon: <BookOpen className="w-5 h-5 text-[#f5a9a9]" />,
      link: '/board/info',
    },
    {
      title: 'MY게시판',
      desc: ['나만의 공간과 기록', '한눈에 확인해요!'],
      icon: <User className="w-5 h-5 text-[#f5a9a9]" />,
      link: '/board/my',
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-[#fbefef]">
      <div className="container mx-auto px-4">
        <div
          className={`flex flex-col ${
            reverse ? 'md:flex-row-reverse' : 'md:flex-row'
          } items-center gap-8 md:gap-16`}
        >
          {/* 텍스트 영역 */}
          <div className="w-full md:w-1/2 text-center md:text-left">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-800 mb-4">
              {title}
            </h2>
            <h3 className="text-xl md:text-2xl text-gray-700 mb-6">
              {subtitle}
            </h3>

            <div className="space-y-4 mb-8">
              {description.map((paragraph, index) => (
                <p key={index} className="text-gray-600 leading-relaxed">
                  {paragraph}
                </p>
              ))}
            </div>

            <a
              href={buttonUrl}
              className="inline-flex items-center px-6 py-3 bg-[#f5a9a9] text-white rounded-lg hover:bg-opacity-90 transition-all transform hover:-translate-y-1"
            >
              {buttonText}
              <ArrowRight className="ml-2 w-4 h-4" />
            </a>
          </div>

          {/* 시각 영역 */}
          <div className="w-full md:w-1/2 flex justify-center md:justify-end">
            <div className="w-full max-w-md h-96 bg-gray-200 rounded-xl overflow-hidden shadow-lg relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#f5a9a9] to-pink-300 opacity-30"></div>

              {showFeatureBoxes ? (
                <div className="absolute inset-0 grid grid-cols-2 gap-4 p-6">
                  {features.map((feature, index) => (
                    <div
                      key={index}
                      className="bg-white bg-opacity-80 rounded-lg shadow p-4 flex flex-col items-start cursor-pointer transform transition-all hover:-translate-y-2 hover:shadow-xl"
                      onClick={() => navigate(feature.link)} //  navigate 사용
                    >
                      <div className="mb-2">{feature.icon}</div>
                      <h4 className="text-sm font-semibold text-gray-800">
                        {feature.title}
                      </h4>
                      {feature.desc.map((line, i) => (
                        <p key={i} className="text-xs text-gray-600">
                          {line}
                        </p>
                      ))}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-gray-500 text-lg">Visual content here</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InfoSection;

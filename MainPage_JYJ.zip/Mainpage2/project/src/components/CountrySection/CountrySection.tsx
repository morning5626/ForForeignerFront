import React from 'react';

interface CountrySectionProps {
  title: string;
  subtitle: string;
  imageSrc: string;
}

const CountrySection: React.FC<CountrySectionProps> = ({ title, subtitle, imageSrc }) => {
  return (
    <div className="relative w-full h-[600px] md:h-[700px] lg:h-[800px]">
      <img
        src={imageSrc}
        alt="Background"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col justify-center items-center text-center px-4">
        <h2 className="text-white text-3xl md:text-5xl font-bold mb-4">{title}</h2>
        <p className="text-white text-lg md:text-2xl">{subtitle}</p>
      </div>
    </div>
  );
};

export default CountrySection;

import { Link, Slide, Feature } from '../types';
import { BookOpen, MessageCircle, Headphones, Globe, BookOpenCheck, UserCheck } from 'lucide-react';

// Define icon components
const BookOpenIcon = () => <BookOpen className="w-6 h-6 text-[#f5a9a9]" />;
const MessageCircleIcon = () => <MessageCircle className="w-6 h-6 text-[#f5a9a9]" />;
const HeadphonesIcon = () => <Headphones className="w-6 h-6 text-[#f5a9a9]" />;
const GlobeIcon = () => <Globe className="w-6 h-6 text-[#f5a9a9]" />;
const BookOpenCheckIcon = () => <BookOpenCheck className="w-6 h-6 text-[#f5a9a9]" />;
const UserCheckIcon = () => <UserCheck className="w-6 h-6 text-[#f5a9a9]" />;

export const navLinks: Link[] = [
  { id: 1, title: 'About Us', url: '#about' },
  { id: 2, title: 'Quiz', url: '#quiz' },
  { id: 3, title: 'Community', url: '#community' },
  { id: 4, title: 'Log In', url: '#login' },
  { id: 5, title: 'Sign In', url: '#signin' },
];

export const heroSlides: Slide[] = [
  {
    id: 1,
    title: '박물관과 함께하는 역사문화탐구',
    subtitle: '삼국시대 기와를 만하다',
    date: '2025.5.7.',
    time: '14:00-18:00',
    location: '교육관 제2강의실',
    image: 'https://images.pexels.com/photos/1181360/pexels-photo-1181360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 2,
    title: '한국어 집중 강좌',
    subtitle: '초보자를 위한 한국어 기초',
    date: '2025.6.15.',
    time: '10:00-12:00',
    location: '온라인 강의',
    image: 'https://images.pexels.com/photos/256417/pexels-photo-256417.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 3,
    title: '문화 체험 투어',
    subtitle: '서울의 역사 탐방',
    date: '2025.7.22.',
    time: '09:00-17:00',
    location: '서울 시내',
    image: 'https://images.pexels.com/photos/2143853/pexels-photo-2143853.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
];

export const features: Feature[] = [
  {
    id: 1,
    title: '어휘 학습',
    description: '게임과 같은 경험으로 한국어 단어를 재미있게 배우세요.',
    icon: <BookOpenIcon />
  },
  {
    id: 2,
    title: '실시간 대화',
    description: '네이티브 한국인과 실시간으로 대화하며 언어 능력을 향상시키세요.',
    icon: <MessageCircleIcon />
  },
  {
    id: 3,
    title: '발음 가이드',
    description: '정확한 한국어 발음을 위한 오디오 가이드와 피드백을 받아보세요.',
    icon: <HeadphonesIcon />
  },
  {
    id: 4,
    title: '문화 이해',
    description: '한국 문화와 관습에 대한 심층적인 정보를 제공합니다.',
    icon: <GlobeIcon />
  },
  {
    id: 5,
    title: '단계별 학습',
    description: '초보자부터 고급 학습자까지 단계별 맞춤 커리큘럼을 제공합니다.',
    icon: <BookOpenCheckIcon />
  },
  {
    id: 6,
    title: '인증 및 평가',
    description: '한국어 능력 평가 및 공식 인증을 위한 준비를 도와드립니다.',
    icon: <UserCheckIcon />
  },
];
import React from 'react';
import Header from './components/Header/Header';
import Hero from './components/Hero/Hero';
import InfoSection from './components/InfoSection/InfoSection';
import AppDemo from './components/AppDemo/AppDemo';
import FeatureSection from './components/FeatureSection/FeatureSection';
import MobilePreview from './components/MobilePreview/MobilePreview';
import CountrySection from './components/CountrySection/CountrySection';
import Footer from './components/Footer/Footer';
import { navLinks, heroSlides, features } from './data/mockData';

import LotteTower from './assets/LotteTower.jpg';

function App() {
  return (
    <div className="min-h-screen bg-[#fbefef]">
      <Header links={navLinks} />
      <Hero slides={heroSlides} />
      <CountrySection 
        title="외국인에 의한, 외국인을 위한 ForForeigner"
        subtitle="한국의 모든 것, 생활부터 언어까지 한번에"
        imageSrc={LotteTower}
      />
      <InfoSection 
        title="한국인 친구들과 대화하고 싶다면?"
        subtitle="퀴즈 게임으로 공부해요!"
        description={[
          "쉬우면서도 어려운 한국어,",
          "게임 속에서 같이 배워가요.",
          "다양한 예문으로 어휘 활용 연습까지!"
        ]}
        buttonText="유행어 공부하기"
        buttonUrl="#examples"
      />
      <AppDemo />
      <InfoSection 
        title="당신의 한국 생활,"
        subtitle="ForForeigner이 함께해요."
        description={[
          "유창하지 않아도, 많이 알지 않아도 괜찮아요.",
          "즐겁고 자유로운 한국어 공부로 달라지는 한국 생활!",
        ]}
        buttonText="퀴즈 게임 하러가기"
        buttonUrl="#start"
        reverse={true}
      />
      <FeatureSection 
        title="ForForeigner와 함께"
        subtitle="한국어 학습과 문화 적응을 위한 완벽한 동반자"
        features={features}
      />
      <MobilePreview
        title="듀유 노 김치 싸대기?"
        description={[
          "K-Drama에서 김치 싸대기를 자주 본 당신.. 명예 한국인",
          "한국인에게 김치란 어떤 걸까?",
          "지금 퀴즈를 통해 k-Drama와 한국 문화에 대해 배워가요."
        ]}
      />
      <Footer />
    </div>
  );
}

export default App;

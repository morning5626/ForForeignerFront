import React from 'react';

const AppDemo: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-lg text-[#f5a9a9] font-medium mb-2">퀴즈 오답을 통한 공부</h2>
          <h3 className="text-2xl md:text-4xl font-bold text-gray-800 mb-4">한국어, 게임하듯 <br className="md:hidden" />쉽고 재밌게</h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            게임하듯 퀴즈를 통해 한국어 공부를 해봐요. <br className="md:hidden" />
            틀린 문제는 오답 풀이를 통해,<br className="md:hidden" />
            복습하여 다시 공부할 수 있어요.
          </p>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16">
          <div className="w-full max-w-xs">
            <div className="bg-[#fbefef] rounded-3xl p-6 shadow-lg transform transition-all hover:scale-105">
              <div className="rounded-xl overflow-hidden bg-white shadow mb-4">
                <div className="px-4 py-3 bg-blue-100 flex items-center">
                  <div className="h-3 w-3 rounded-full bg-yellow-400 mr-2"></div>
                  <div className="text-sm text-blue-800 font-medium">유행어</div>
                </div>
                <div className="p-4">
                  <p className="text-sm text-gray-500 mb-2">너의 헤어스타일은 느좋이야!</p>
                  <p className="text-sm text-gray-800 mb-3">Your hair style is so __ !</p>
                  <div className="flex justify-end">
                    <div className="bg-[#f5a9a9] text-white text-xs px-2 py-1 rounded">정답 입력하기</div>
                  </div>
                </div>
              </div>
              <p className="text-center text-sm text-gray-600">간단한 문장으로 단어의 쓰임을 배워보세요.</p>
            </div>
          </div>

          <div className="w-full max-w-xs">
            <div className="bg-[#fbefef] rounded-3xl p-6 shadow-lg">
              <div className="relative">
                                <div className="absolute -top-6 -right-6 bg-[#f5a9a9] text-white rounded-full w-12 h-12 flex items-center justify-center text-lg font-bold">
                 예문
                </div>
                <div className="rounded-xl overflow-hidden bg-white shadow mb-4">
                  <div className="px-4 py-3 bg-blue-100 flex items-center">
                    <div className="h-3 w-3 rounded-full bg-yellow-400 mr-2"></div>
                    <div className="text-sm text-blue-800 font-medium">역사</div>
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-gray-600 mb-1">독도는 어느 나라 땅일까요?</p>
                    <p className="text-sm text-gray-500"> 1. 한국  2. 마다가스카르 3. 아르헨티나 </p>
                  </div>
                </div>
              </div>
              
              <p className="text-center text-sm text-gray-600">다양한 퀴즈를 통해서 역사를 학습하세요.</p>
            </div>
          </div>

          <div className="w-full max-w-xs hidden md:block">
            <div className="bg-[#fbefef] rounded-3xl p-6 shadow-lg transform transition-all hover:scale-105">
              <div className="rounded-xl overflow-hidden bg-white shadow mb-4">
                <div className="relative overflow-hidden h-40">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-gray-800 font-medium">나의 한국어 점수</p>
                      <div className="text-3xl font-bold text-[#f5a9a9]">85%</div>
                    </div>
                  </div>
                </div>
              </div>
              <p className="text-center text-sm text-gray-600">학습 성취도를<br></br> 실시간으로 확인하세요.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppDemo;
import React from 'react';

interface CountrySectionProps {
  title: string;
  subtitle: string;
  imageSrc: string;
}

const CountrySection: React.FC<CountrySectionProps> = ({
  title,
  subtitle,
  imageSrc
}) => {
  return (
    <section className="py-16 bg-white border-t border-gray-100">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="w-full md:w-1/2">
            <img 
              src={imageSrc} 
              alt={title} 
              className="w-full h-auto rounded-lg shadow-md"
            />
          </div>
          
          <div className="w-full md:w-1/2">
            <h2 className="text-3xl font-bold mb-4">
              <span className="text-red-500">South</span>{' '}
              <span className="text-blue-600">Korea</span>
            </h2>
            <p className="text-lg text-gray-800 mb-4">{title}</p>
            <p className="text-gray-600">{subtitle}</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CountrySection;
import React from 'react';

interface MobilePreviewProps {
  title: string;
  description: string[];
  imageSrc?: string;
}

const MobilePreview: React.FC<MobilePreviewProps> = ({
  title,
  description,
  imageSrc,
}) => {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-16">
          <div className="w-full md:w-1/2 order-2 md:order-1">
            <div className="max-w-sm mx-auto">
              <div className="relative w-64 h-[500px] mx-auto">
                {/* Phone Frame */}
                <div className="absolute inset-0 bg-gray-200 rounded-[40px] shadow-xl overflow-hidden border-8 border-gray-300">
                  {/* Screen Content */}
                  <div className="h-full bg-blue-100 flex flex-col">
                    {/* Status Bar */}
                    <div className="bg-blue-200 px-4 py-2 flex items-center justify-between">
                      <div className="w-4 h-4 bg-yellow-400 rounded-full"></div>
                      <div className="text-xs text-blue-600 font-medium">단어</div>
                      <div className="w-4 h-4 bg-gray-400 rounded-full"></div>
                    </div>
                    
                    {/* Chat Bubbles */}
                    <div className="flex-1 p-4 space-y-4 overflow-y-auto">
                      <div className="bg-blue-50 p-3 rounded-lg max-w-[80%] self-start">
                        <p className="text-xs text-gray-700">내 범어 우수 출석자 알장마?</p>
                      </div>
                      
                      <div className="bg-white p-3 rounded-lg max-w-[80%] ml-auto">
                        <p className="text-xs text-gray-700">Do you ____ what I mean?</p>
                      </div>
                    </div>
                    
                    {/* Keyboard */}
                    <div className="bg-gray-200 p-1">
                      <div className="grid grid-cols-10 gap-1">
                        {['q','w','e','r','t','y','u','i','o','p',
                          'a','s','d','f','g','h','j','k','l',
                          'z','x','c','v','b','n','m'].map((key) => (
                          <div key={key} className="bg-white rounded text-[8px] h-8 flex items-center justify-center">
                            {key}
                          </div>
                        ))}
                      </div>
                      
                      <div className="flex justify-between mt-1">
                        <div className="bg-gray-300 rounded px-2 py-1 text-[8px]">한/영</div>
                        <div className="bg-white rounded px-4 py-1 text-[8px]">스페이스</div>
                        <div className="bg-gray-300 rounded px-2 py-1 text-[8px]">확인</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="w-full md:w-1/2 order-1 md:order-2 text-center md:text-left">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-800 mb-6">
              {title}
            </h2>
            
            <div className="space-y-4 mb-8">
              {description.map((paragraph, index) => (
                <p key={index} className="text-gray-600 leading-relaxed">{paragraph}</p>
              ))}
            </div>
            
            <button className="px-6 py-3 bg-[#f5a9a9] text-white rounded-lg hover:bg-opacity-90 transition-all transform hover:translate-y-[-2px]">
              앱 다운로드
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MobilePreview;
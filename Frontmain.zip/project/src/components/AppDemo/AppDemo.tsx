import React from 'react';

const AppDemo: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-lg text-[#f5a9a9] font-medium mb-2">어휘카드</h2>
          <h3 className="text-2xl md:text-4xl font-bold text-gray-800 mb-4">영단어, 게임하듯 <br className="md:hidden" />쉽고 재밌게</h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            게임하듯 영단어 워드를 풀어 보세요. <br className="md:hidden" />
            다양한 전하며 푸풀 알려주고, <br className="md:hidden" />
            챌린지는 포인트로 획심히 쳐여요.
          </p>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16">
          <div className="w-full max-w-xs">
            <div className="bg-[#fbefef] rounded-3xl p-6 shadow-lg transform transition-all hover:scale-105">
              <div className="rounded-xl overflow-hidden bg-white shadow mb-4">
                <div className="px-4 py-3 bg-blue-100 flex items-center">
                  <div className="h-3 w-3 rounded-full bg-yellow-400 mr-2"></div>
                  <div className="text-sm text-blue-800 font-medium">단어</div>
                </div>
                <div className="p-4">
                  <p className="text-sm text-gray-500 mb-2">내 범어 우수 출석자 알장마?</p>
                  <p className="text-sm text-gray-800 mb-3">Do you _____ what I mean?</p>
                  <div className="flex justify-end">
                    <div className="bg-[#f5a9a9] text-white text-xs px-2 py-1 rounded">catch</div>
                  </div>
                </div>
              </div>
              <p className="text-center text-sm text-gray-600">간단한 문장으로 단어의 쓰임을 배워보세요.</p>
            </div>
          </div>

          <div className="w-full max-w-xs">
            <div className="bg-[#fbefef] rounded-3xl p-6 shadow-lg">
              <div className="relative">
                <div className="absolute -top-6 -right-6 bg-[#f5a9a9] text-white rounded-full w-12 h-12 flex items-center justify-center text-lg font-bold">
                  예문
                </div>
                <div className="rounded-xl overflow-hidden bg-white shadow mb-4">
                  <div className="px-4 py-3 bg-blue-100 flex items-center">
                    <div className="h-3 w-3 rounded-full bg-yellow-400 mr-2"></div>
                    <div className="text-sm text-blue-800 font-medium">catch</div>
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-gray-600 mb-1">I'll throw the ball. Let's see if you can catch it.</p>
                    <p className="text-sm text-gray-500">내가 공을 던질게. 네가 잡을 수 있는지 보자.</p>
                  </div>
                </div>
              </div>
              <p className="text-center text-sm text-gray-600">다양한 예문을 통해 어휘를 학습하세요.</p>
            </div>
          </div>

          <div className="w-full max-w-xs hidden md:block">
            <div className="bg-[#fbefef] rounded-3xl p-6 shadow-lg transform transition-all hover:scale-105">
              <div className="rounded-xl overflow-hidden bg-white shadow mb-4">
                <div className="relative overflow-hidden h-40">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-gray-800 font-medium">어휘 점수</p>
                      <div className="text-3xl font-bold text-[#f5a9a9]">85%</div>
                    </div>
                  </div>
                </div>
              </div>
              <p className="text-center text-sm text-gray-600">학습 성취도를 실시간으로 확인하세요.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppDemo;
import React from 'react';
import { Phone, Mail, MapPin, Github, Twitter, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#f5a9a9] text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">ForForeigner</h3>
            <p className="mb-4">
              Helping foreign residents and visitors navigate life in Korea with 
              language learning, cultural resources, and community support.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-white/80 transition-colors">
                <Github size={20} />
              </a>
              <a href="#" className="hover:text-white/80 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="hover:text-white/80 transition-colors">
                <Facebook size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Phone size={16} className="mr-2" />
                <span>+82-2-2229-6969</span>
              </li>
              <li className="flex items-center">
                <Mail size={16} className="mr-2" />
                <span>hotline@for-foreign.kr</span>
              </li>
              <li className="flex items-center">
                <MapPin size={16} className="mr-2" />
                <span>Seoul Metropolitan Government</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="hover:underline">About Us</a>
              </li>
              <li>
                <a href="#" className="hover:underline">Resources</a>
              </li>
              <li>
                <a href="#" className="hover:underline">Community</a>
              </li>
              <li>
                <a href="#" className="hover:underline">Privacy Policy</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-4 border-t border-white/20 text-sm text-white/70 flex flex-col md:flex-row justify-between items-center">
          <p>Copyright © 2023-2025 Seoul Metropolitan Government. All Rights Reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <img src="https://via.placeholder.com/80x30/ffffff/cccccc?text=CERT1" alt="Certification" className="h-6" />
            <img src="https://via.placeholder.com/80x30/ffffff/cccccc?text=CERT2" alt="Certification" className="h-6" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
import React from 'react';
import Header from './components/Header/Header';
import Hero from './components/Hero/Hero';
import InfoSection from './components/InfoSection/InfoSection';
import AppDemo from './components/AppDemo/AppDemo';
import FeatureSection from './components/FeatureSection/FeatureSection';
import MobilePreview from './components/MobilePreview/MobilePreview';
import CountrySection from './components/CountrySection/CountrySection';
import Footer from './components/Footer/Footer';
import { navLinks, heroSlides, features } from './data/mockData';

function App() {
  return (
    <div className="min-h-screen bg-[#fbefef]">
      <Header links={navLinks} />
      <Hero slides={heroSlides} />
      
      <InfoSection 
        title="비슷한듯 다른 뜻,"
        subtitle="문장으로 이해해요."
        description={[
          "상황마다 조금씩 달라지는 단어 뜻,",
          "문장 속에서 찾을 수 있어요.",
          "다양한 예문으로 어휘 활용 연습까지!"
        ]}
        buttonText="예문 확인하기"
        buttonUrl="#examples"
      />
      
      <AppDemo />
      
      <InfoSection 
        title="당신의 내일,"
        subtitle="오늘보다 더 멋질 거예요."
        description={[
          "유창하지 않아도, 많이 알지 않아도 괜찮아요.",
          "즐겁고 자유로운 영어로 달라지는 나를 만나기.",
          "당신의 멋진 내일, 함께 보자가 함께 할게요."
        ]}
        buttonText="오늘부터 우리, 함께 해봐요!"
        buttonUrl="#start"
        reverse={true}
      />
      
      <FeatureSection 
        title="ForForeigner와 함께"
        subtitle="한국어 학습과 문화 적응을 위한 완벽한 동반자"
        features={features}
      />
      
      <MobilePreview
        title="비슷한듯 다른 뜻, 문장으로 이해해요."
        description={[
          "상황마다 조금씩 달라지는 단어 뜻, 문장 속에서 찾을 수 있어요.",
          "다양한 예문으로 어휘 활용 연습까지!",
          "지금 앱을 다운로드하고 언제 어디서나 한국어를 학습하세요."
        ]}
      />
      
      <CountrySection 
        title="외국인에 의한, 외국인을 위한 ForForeigner"
        subtitle="한국의 모든 것, 생활부터 언어까지 한번에"
        imageSrc="https://images.pexels.com/photos/427679/pexels-photo-427679.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
      />
      
      <Footer />
    </div>
  );
}

export default App;